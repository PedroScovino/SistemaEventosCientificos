package projetodev.eventosapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventosApiRestApplication.class, args);
	}

}
